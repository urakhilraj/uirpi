<?php
return array (
  'thresholds' =>
  array (
    'warn_cpu_temp' => '65',
    'warn_ram_space' => '80',
    'warn_loads_size' => '2',
    'upd_time_interval' => '15',
  ),
  'general' =>
  array (
    'pass' => '63a9f0ea7bb98050796b649e85481845',
    'initialsetup' => '0',
    'tempunit' => '0'
  ),
);
?>
